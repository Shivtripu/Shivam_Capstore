package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.service.IInviteFriendService;

@Controller
public class InviteFriendController {
	
	@Autowired
	private IInviteFriendService inviteFriendService;

	@RequestMapping("/")
	public String inviteFriend(String mobileNo)  {
		inviteFriendService.inviteFriend(mobileNo);
		return mobileNo;
		
	}
	
}
