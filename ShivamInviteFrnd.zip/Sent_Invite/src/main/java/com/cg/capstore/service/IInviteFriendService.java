package com.cg.capstore.service;

public interface IInviteFriendService {
	
	public String inviteFriend(String mobileNo);

}
