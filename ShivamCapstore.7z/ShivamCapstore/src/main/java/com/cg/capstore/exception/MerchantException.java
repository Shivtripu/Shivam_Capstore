package com.cg.capstore.exception;

@SuppressWarnings("serial")
public class MerchantException extends Exception {
	public MerchantException() {
		super();
	
	}

	public MerchantException(String message) {
		super(message);
		
	}

}
