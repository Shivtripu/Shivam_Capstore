package com.cg.capstore.service;



public interface IInvoiceService {

	public String generateInvoice(String customerId);
	
}
