package com.cg.capstore.service;

import org.springframework.stereotype.Service;

@Service
public class FeedbackComon implements IFeedbackCommon {

	@Override
	public String feedbackCommon(FeedbackCommon feedback) {
		// TODO Auto-generated method stub
		return null;
	}

}
