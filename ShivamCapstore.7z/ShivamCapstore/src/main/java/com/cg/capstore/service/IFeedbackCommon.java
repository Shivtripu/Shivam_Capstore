package com.cg.capstore.service;

public interface IFeedbackCommon {

	
	public String feedbackCommon(FeedbackCommon feedback);
	
	
	
}
