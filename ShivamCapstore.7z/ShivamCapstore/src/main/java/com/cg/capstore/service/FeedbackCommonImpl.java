package com.cg.capstore.service;

public class FeedbackCommonImpl implements FeedbackCommon {

	@Override
	public void getComments(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void forwardToMerchant(String forwardMessage) {
		// TODO Auto-generated method stub

	}

	@Override
	public void responseFromMerchant(String responseMessage) {
		// TODO Auto-generated method stub

	}

}
