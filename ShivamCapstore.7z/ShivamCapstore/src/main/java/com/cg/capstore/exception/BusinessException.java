package com.cg.capstore.exception;

public class BusinessException extends Exception{

	public BusinessException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BusinessException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
